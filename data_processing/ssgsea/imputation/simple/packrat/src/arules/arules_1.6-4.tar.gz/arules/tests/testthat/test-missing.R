## FIXME: missing tests
## * itemCoding
## * aggregate
## * dissimilarity
## * pmml
## * predict
## * supportingTransactions

