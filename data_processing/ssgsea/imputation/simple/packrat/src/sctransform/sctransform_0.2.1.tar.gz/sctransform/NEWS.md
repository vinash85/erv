# News
All notable changes will be documented in this file.

## [0.2.1] - 2019-12-17
### Added
- Add function to generate data given the output of a vst run
- Add cpp support for dense integer matrices
- Minimum variance parameter added to vst function

## [0.2.0] - 2019-04-12
### Added
- Rcpp versions of utility functions
- Helper functions to get corrected UMI and variance of pearson residuals for large UMI matrices

### Changed
- lots of things
