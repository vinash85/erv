library(testthat)
library(mutoss)

test_check("mutoss")
